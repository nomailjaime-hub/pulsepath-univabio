# PulsePath — Demo Video Script (about 90 seconds)

**Video title:** PulsePath — Explainable Health Trend Tracking | UnivaBio 2026

**Opening (0:00–0:10) — show Home**
“Health changes can be difficult to explain from memory alone. PulsePath helps people organise repeated health observations into a clear timeline and see exactly what changed.”

**Set the context (0:10–0:20) — show the demo-mode notice**
“This is a health-observation prototype, not a diagnostic tool. The current experience uses fictional demo data, and private check-in saving is not enabled.”

**Timeline (0:20–0:40) — open Timeline and scroll through the four fictional records**
“Here are four fictional daily check-ins. Instead of presenting a one-time symptom guess, PulsePath keeps the observations in chronological order so the progression is easy to review.”

**Evidence Trace (0:40–1:05) — open Insight and point to the baseline/latest values**
“The Evidence Trace compares the earliest and latest recorded observations. In this scenario, wellbeing changes from 8 to 4, cough severity rises from 2 to 8, breathing difficulty rises from 0 to 6, and temperature rises from 37.2 to 39 degrees Celsius. Each difference is shown with the supporting values and observation dates. Heart rate and SpO2 remain marked missing—not zero—because no readings were entered.”

**Responsible use (1:05–1:20) — show Safety & Privacy**
“PulsePath explains the observed change; it does not infer a disease or claim that a number alone establishes clinical significance. The fictional dataset makes the demo safe to explore, and the current prototype does not save new private check-ins.”

**Closing (1:20–1:30) — return to Insight or Home**
“Our goal is to make health observations easier to see, verify, and discuss with a healthcare professional. PulsePath: See the change. Explain the change. Act earlier.”

## Recording notes
- Record the real app; do not use mockups as if they were working screens.
- Use only fictional demo records.
- Keep the demo mode / no-saving limitation visible when relevant.
- Do not imply the app has generative AI, diagnosis, clinical validation, or real-person data persistence.
- Check the actual preview at desktop and 375 px mobile widths before recording; editor settings alone are not visual verification.

## YouTube description
PulsePath is a health-observation tracking prototype built for UnivaBio 2026. It organises fictional check-ins into a timeline and provides an Evidence Trace showing baseline values, latest values, observation dates, and calculated changes. The project focuses on transparent trend communication rather than disease diagnosis.

This demonstration uses fictional data only. Private check-in saving is not enabled. PulsePath is not a diagnostic tool and does not replace professional medical care.

#UnivaBio #HealthTech #DigitalHealth #ExplainableAI #Momen
