# PulsePath Project Gallery Guide

Recommended actual app screenshots (capture them from the running Momen preview; do not recreate or fabricate app screens):

1. Insight / Evidence Trace — make the four metric changes and two missing metrics visible.
2. Timeline — show all four fictional entries with their dates and values.
3. Home — show the tagline and the product purpose.
4. Check-in — include the visible demo-only/no-save notice.
5. Safety & Privacy — show the non-diagnostic limitation.

Devpost gallery constraints supplied for this submission: JPG, PNG or GIF; 5 MB maximum per image; 3:2 ratio recommended; up to 15 images.

On macOS with Chrome:
1. Open the active Momen preview link while it is valid.
2. Navigate to the page you want to capture. Ensure the demo-only notice is visible where appropriate.
3. Use Chrome DevTools' device toolbar or responsive viewport, set a viewport such as 1200 × 800 for a 3:2 capture, then capture only the app viewport (not browser tabs or private editor controls).
4. Save each actual page as PNG. Check the pixel dimensions and file size before uploading.
5. Use clear file names such as `01-insight-evidence-trace.png`, `02-timeline.png`, `03-home.png`, `04-check-in-demo-notice.png`, and `05-safety-privacy.png`.

`assets/PulsePath_Project_Graphic.png` is a promotional graphic, not an actual app screenshot. It is 1536 × 1024 (3:2) and can be used as a gallery/cover graphic if desired.
