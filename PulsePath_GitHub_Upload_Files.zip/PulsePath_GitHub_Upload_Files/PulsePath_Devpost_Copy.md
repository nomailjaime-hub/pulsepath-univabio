# PulsePath — Devpost Submission Copy

## Project title
PulsePath

## Tagline
See the change. Explain the change. Act earlier.

## Short description
PulsePath is a health-observation tracking prototype that turns repeated symptom check-ins into a chronological timeline and an explainable baseline-to-latest comparison. It helps people organise reported changes for discussion with a healthcare professional without claiming to diagnose disease.

## Inspiration
Health observations are often recorded inconsistently or remembered only after symptoms have changed. It can be difficult to explain when a symptom started, whether it is getting worse, and which measurements were actually recorded. PulsePath explores a simple alternative: preserve the timeline and show the arithmetic behind each reported change.

## What it does
- **Check-in:** capture wellbeing, cough severity, breathing difficulty, and optional temperature, heart-rate, and SpO2 observations.
- **Timeline:** present fictional check-ins in chronological order.
- **Insight:** compare the earliest available observation with the latest.
- **Evidence Trace:** show values, observation dates, numerical differences, plain-language explanations, and missing-data status.
- **Safety-first framing:** describe observations rather than generating a disease diagnosis; missing data is not treated as zero.

## What makes it different
PulsePath emphasises traceability over a black-box disease guess. Every displayed change can be checked against its baseline value, latest value, dates, and calculation. The prototype is designed to help users describe what they observed—not tell them what condition they have.

## How we built it
PulsePath was built as a no-code Web app with Momen. Its current implementation uses database-backed fictional demo records and deterministic baseline-to-latest calculations. The Evidence Trace displays the source observations and explains how the numerical changes were calculated. No generative AI Health Brief is implemented in the current version; this keeps the prototype's output deterministic and avoids presenting unsupported AI-generated medical claims as validated guidance.

## Demonstration
The demo uses four fictional daily check-ins. Over the sample timeline, reported wellbeing changes from 8 to 4, cough severity from 2 to 8, breathing difficulty from 0 to 6, and temperature from 37.2 °C to 39.0 °C. Heart rate and SpO2 are shown as missing because no readings were entered. These values demonstrate the app's calculations only and are not clinical predictions.

## Limitations and responsible use
This is a prototype, not a diagnostic tool or substitute for professional medical care. It uses fictional demonstration records. Private check-in saving is not enabled, and the Save button explains that the information is not saved. No clinical validation or diagnostic performance is claimed. A future version would need verified access controls, private persistence, clinical review, and appropriate validation before handling real health information.

## Built with
Momen Web app platform; Momen database; deterministic baseline-to-latest calculations; responsive interface components.

## Suggested project links to fill before submission
- Live demo: [PASTE THE PUBLIC TEST/PRODUCTION URL]
- Demo video: [PASTE THE VIDEO URL]
- Source/code documentation: [PASTE A PUBLIC REPOSITORY OR ELIGIBLE CODE/IMPLEMENTATION PDF]
