# PulsePath — Implementation Overview

## Implemented in the Momen no-code app

- Navigation across Home, Check-in, Timeline, Insight, and Safety & Privacy.
- Timeline reads the existing CheckIn records.
- Insight compares the earliest and latest observations.
- Evidence Trace shows observation dates, metric values, numerical differences, plain-language calculation explanations, and missing-data statuses.
- Heart rate and SpO₂ are explicitly shown as missing in the current fixture; missing values are not converted to zero.
- The Check-in Save button only shows a warning. It does not create a database record.

## Calculation specification

```text
For each metric:
  observations = values for that metric ordered by recorded date
  valid_observations = observations with an actual value (not null/missing)

  if count(valid_observations) < 2:
      status = "Insufficient history" or "Missing"
      do not calculate a change
  else:
      baseline = first valid observation
      latest = last valid observation
      change = latest - baseline
      display baseline, latest, dates, and change
```

The code block above is an explanatory specification, not an export of Momen-generated source code. The working project logic is configured in Momen.

## Current fictional test fixture

| Metric | Baseline | Latest | Difference |
|---|---:|---:|---:|
| Wellbeing | 8 | 4 | -4 points |
| Cough severity | 2 | 8 | +6 points |
| Breathing difficulty | 0 | 6 | +6 points |
| Temperature | 37.2 °C | 39.0 °C | +1.8 °C |
| Heart rate | Missing | Missing | Not calculated |
| SpO₂ | Missing | Missing | Not calculated |

## Known limitations

- No private check-in persistence for new entries.
- No runtime AI Health Brief or AI diagnostic function.
- Actual rendered-preview verification should be recorded separately from editor configuration checks.
- The current data-permission comparison does not prove that non-demo records would be hidden, because the dataset contains only the demo fixture.

## Safety

The output describes observed data only. Numerical changes do not prove a diagnosis, and this prototype should not be used to make medical decisions.
