# PulsePath — Explainable Health-Change Tracking

**Tagline:** See the change. Explain the change. Act earlier.

PulsePath is a health-observation tracking prototype that compares a baseline check-in with the latest available check-in and presents the differences in an Evidence Trace. It is designed to help people organise observations and discuss changes with a healthcare professional; it is not a diagnostic tool.

## Current prototype

The web experience was built with Momen's no-code editor. The current implementation contains Home, Check-in, Timeline, Insight, and Safety & Privacy pages. The Insight page includes a deterministic Evidence Trace based on existing observations.

### Demonstration results

The current fixture contains four fictional check-ins. The observed baseline-to-latest comparisons are:

- Wellbeing: 8 → 4 (−4 points)
- Cough severity: 2 → 8 (+6 points)
- Breathing difficulty: 0 → 6 (+6 points)
- Temperature: 37.2 °C → 39.0 °C (+1.8 °C)
- Heart rate and SpO₂: missing, so no change is calculated

All records above are fictional demonstration data, not clinical evidence or a medical prediction.

## Important implementation limits

- New private check-in saving is **not enabled**. The Save button displays a warning and does not write a new record.
- The current product has a deterministic Evidence Trace, not a runtime AI diagnostic or AI-generated Health Brief.
- Use fictional information only. Do not enter personal health information.
- Momen's current preview link is temporary and may expire. Replace any temporary link here only after confirming its availability and expiry.
- This repository is a transparency and submission-documentation package. **It is not an exported source-code copy of the Momen web app.** The app was authored in Momen's no-code editor; this repository does not claim otherwise.

## Technical overview

### Data model used by the prototype

**HealthProfile**: profile identifier and demo-profile flag.

**CheckIn**: profile relation, recorded date/time, wellbeing score, cough score, breathing-difficulty score, optional temperature, optional heart rate, optional SpO₂, and optional note.

### Calculation method

For each available metric:

`change = latest valid observation - earliest valid observation`

A trend is not calculated if there are fewer than two valid observations for that metric. Missing measurements are not interpreted as zero. Interpretation differs by metric: a lower wellbeing score represents lower reported wellbeing, while higher symptom-severity scores represent increased reported severity. Observed changes alone do not establish clinical significance or a diagnosis.

## Screens and demo

The project walkthrough should show:

1. Home — purpose and safety boundary.
2. Check-in — input form and demo-only/no-save warning.
3. Timeline — the four fictional records in chronological order.
4. Insight — Evidence Trace and missing-data handling.
5. Safety & Privacy — limitations and appropriate use.

## Repository contents

- `docs/PulsePath_One_Page_Project_Description.pdf` — one-page project overview.
- `docs/PulsePath_Devpost_Copy.md` — draft Devpost description.
- `docs/PulsePath_Demo_Video_Script.md` — demo narration and video description.
- `assets/PulsePath_Project_Graphic.png` — promotional graphic, not a screenshot of the running application.

## Safety notice

PulsePath is an early-stage demonstration. It does not diagnose, predict or rule out disease; it does not replace professional medical advice. The demo data is fictional and new private check-in saving is disabled.
